'''
using module as a singleton class.
'''

uid = 0
saltedUID = ""
userName = ""
orgNr:int

# orgNr - 4 digit code
 
def setSuperUser(name:str, orgNrInput:int):
    if (len(str(orgNrInput))!=4):
        raise NameError("orgNr should be a 4 digit code")
    userName = name
    orgNr = orgNrInput
    saltedUID = str(uid) + str(orgNr)





